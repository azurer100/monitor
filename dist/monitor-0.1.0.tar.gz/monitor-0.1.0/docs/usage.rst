=====
Usage
=====

To use monitor in a project::

    import monitor
